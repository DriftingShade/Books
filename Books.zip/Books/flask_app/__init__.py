from flask import Flask

app = Flask(__name__)
app.secret_key = "SSede/xcd2e12eaace8asd2gh2t2a33325d25a2345 535ads./wp-aew"
